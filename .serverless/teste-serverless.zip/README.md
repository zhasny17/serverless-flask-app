application with serverless and flask for some study!

installing frameworks: 
pip install -r requirements.txt

starts a local database for test purposes:
sls dynamodb start  