application with serverless and flask for some study!

pip install -r requirements.txt